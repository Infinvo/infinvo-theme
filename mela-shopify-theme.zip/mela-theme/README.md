# Mela — Marketplace theme for Shopify

A marketplace-style homepage inspired by the density and shopping patterns of Flipkart, Amazon, and Meesho, built for a fashion + home accessories store. Color palette: marigold orange, deep indigo, and rani pink on a warm ivory background — festive-market feel without copying any of those brands' actual branding.

## What's included
- `layout/theme.liquid` — page shell, loads Google Fonts (Baloo 2 + Work Sans) and theme.css/js
- `sections/announcement-bar.liquid` — top utility strip (delivery promise, track order, sell on store)
- `sections/header.liquid` — logo, category-scoped search bar, account/cart icons
- `sections/category-nav.liquid` — sticky category strip under the header
- `sections/hero-banner.liquid` — large promo banner + two side tiles (editable in theme editor)
- `sections/category-circles.liquid` — Meesho-style circular category rail
- `sections/flash-deals.liquid` — dark deal block with a live countdown timer, pulls from a collection you choose
- `sections/product-grid.liquid` — reusable section, add as many as you like, each pointed at a different collection
- `sections/trust-strip.liquid` — verified sellers / returns / delivery / secure payment icons
- `sections/footer.liquid` — link columns (from your existing menus) + newsletter signup
- `sections/main-product.liquid`, `main-collection-product-grid.liquid`, `main-cart-items.liquid` — minimal product, collection, and cart pages in the same style
- `snippets/product-card.liquid` — the marketplace-style product card (image, discount badge, rating, price + strikethrough MRP) used everywhere
- `templates/index.json`, `product.json`, `collection.json`, `cart.json` — homepage and standard page templates
- `assets/theme.css`, `assets/theme.js` — all styling and the countdown-timer script

## Installing on your store
1. Zip the `mela-theme` folder (the zip you received already has this done).
2. In Shopify admin: **Online Store → Themes → Add theme → Upload zip file**.
3. Once uploaded, click **Customize** to preview it before publishing.
4. Publish when you're happy with it.

## After installing — what to set up
- **Homepage sections**: in the theme editor, open each `Product grid` section and pick a real collection (e.g. "Fashion trending", "Home essentials") from your store.
- **Flash deals**: set a collection and an end date/time (`Countdown end` field, format `2026-09-20T23:59:00`) on the Flash deals section.
- **Category nav / category circles**: edit the blocks to match your actual product categories and link them to your real collection pages.
- **Footer columns**: point each column at an existing menu (Settings → Navigation) rather than typing links by hand.
- **Store name**: the logo currently falls back to your store name in lowercase (e.g. "mela."). Upload a real logo image in the Header section once you have one, or rename your store to change the wordmark.
- **Reviews/ratings**: the product card looks for a `reviews.rating` metafield — if you use a reviews app, map its rating metafield there, or remove that block from `snippets/product-card.liquid`.

## Customizing the look
All colors and both typefaces are defined as CSS variables at the top of `assets/theme.css` (`--mela-marigold`, `--mela-indigo`, `--mela-rani`, `--mela-ivory`, `--font-display`, `--font-body`). Change the hex values there to re-theme the whole store at once.

## Note on the name "Mela"
"Mela" (meaning fair/market) is used as a placeholder brand name throughout — it's just editable text and a wordmark, not hardcoded branding. Swap it for your real store name in Shopify admin settings and the header will pick it up automatically.
