document.addEventListener('DOMContentLoaded', function () {
  var timer = document.querySelector('[data-mela-countdown]');
  if (!timer) return;

  var endAttr = timer.getAttribute('data-mela-countdown');
  var endTime = endAttr ? new Date(endAttr).getTime() : Date.now() + 1000 * 60 * 60 * 6;

  var hrsEl = timer.querySelector('.hrs');
  var minsEl = timer.querySelector('.mins');
  var secsEl = timer.querySelector('.secs');

  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  function tick() {
    var diff = Math.max(0, endTime - Date.now());
    var hrs = Math.floor(diff / 3600000);
    var mins = Math.floor((diff % 3600000) / 60000);
    var secs = Math.floor((diff % 60000) / 1000);
    if (hrsEl) hrsEl.textContent = pad(hrs);
    if (minsEl) minsEl.textContent = pad(mins);
    if (secsEl) secsEl.textContent = pad(secs);
    if (diff > 0) requestAnimationFrame(function () { setTimeout(tick, 1000); });
  }
  tick();
});
